export default function HistoryTable(){
  return <div className="card">📜 Lịch sử sẽ cập nhật ở bản sau.</div>;
}

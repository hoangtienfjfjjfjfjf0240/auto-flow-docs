# Flow Automation Studio (by tienhv)

- UI sáng (white/blue), Next.js + Tailwind
- Nhập Bearer Token (lưu localStorage)
- Gửi prompt (kèm URL ảnh) → nhận JSON
- Docs hiển thị Markdown (tab **Docs**)

## Dev
```bash
npm i
npm run dev
```

## Build
```bash
npm run build
npm start
```

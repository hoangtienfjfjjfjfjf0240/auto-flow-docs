# Flow Automation Studio (by tienhv)

Giao diện web **sáng (white/blue)** để chạy prompt online với Google Flow API.

## Cách dùng nhanh
1. Vào tab **Settings** → dán **Bearer Token** (token thay đổi theo ngày).
2. Vào tab **Control** → nhập prompt (và link ảnh nếu có) → **Run**.
3. Xem JSON trả về ở dưới.

> *Lưu ý*: Đây là bản demo API. Để kết nối API thật của Google Flow, thay endpoint trong `/lib/flowApi.js`.
